files = {'stand.mat', 'leg1.mat', 'leg2.mat'};  % For "K" only

% --- Transform settings ---

% Offsets for "K" part
offsets_K = [-20, 0;    % stand.mat for "K"
              0, 0;     % leg1.mat
              0, 0];    % leg2.mat

% Scales for "K"
scales_K = [1.0, 1.0;
            4.0, 0.9;
            0.8, 0.5];

% Slopes for "K"
slopes_K = [1, 0;
            1.2, 0.8;
            0.8, 1.3];

% === "H" will reuse stand.mat three times separately ===

% Load stand.mat once for H parts
load('stand.mat');
ax_H = Acceleration.X;
ay_H = Acceleration.Y;
t_H = seconds(Acceleration.Timestamp - Acceleration.Timestamp(1));
vx_H = cumtrapz(t_H, ax_H);
vy_H = cumtrapz(t_H, ay_H);
x0_H = cumtrapz(t_H, vx_H);
y0_H = cumtrapz(t_H, vy_H);

% Manual transforms for each of the 3 H logs:
offsets_H = [
    -20, 30;   % Left vertical of H
    -20, 55;   % Right vertical of H
    0, 30      % Crossbar
];

scales_H = [
    1.0, 1.0;
    1.0, 1.0;
    1.0, 1.0
];

slopes_H = [
    1.0, 0;
    1, 0;
    0, 1.8
];

% === Adding the rest of the letters A, L, I, M, Z, O, D, A ===
% Load the stand.mat data once to reuse for all additional letters
ax_std = ax_H;
ay_std = ay_H;
t_std = t_H;
vx_std = vx_H;
vy_std = vy_H;
x0_std = x0_H;
y0_std = y0_H;

% Letter group sizes as specified: 3,2,1,4,3,4,4,3
group_sizes = [3, 2, 1, 4, 3, 4, 3, 3];
letter_labels = {'A1', 'L', 'I', 'M', 'Z', 'O', 'D', 'A2'};

% Starting horizontal position for the first A after H
current_pos = 80;
spacing = 35;  % Spacing between letters

% Settings for each letter group
% A1 (3 components)
offsets_A1 = [
    +25, current_pos;          % Left diagonal
    -20, current_pos-15;     % Right diagonal
    0, current_pos-10             % Horizontal bar
];

scales_A1 = [
    1.0, 1;
    1.0, 1;
    0.1, 1.0
];

slopes_A1 = [
    -1, 1.2;    % Left diagonal sloping up and left
    1, 1.2;     % Right diagonal sloping up and right
    0, 1.2        % Horizontal bar
];

current_pos = current_pos + spacing;

% L (2 components)
offsets_L = [
    -20, current_pos-10;          % Vertical
    -20, current_pos-9             % Horizontal
];

scales_L = [
    0.9, 0.7;
    1.0, 2
];

slopes_L = [
    1.2, 0;       % Vertical down
    0, 1.0        % Horizontal right
];

current_pos = current_pos + spacing;

% I (1 component)
offsets_I = [
    -20, current_pos-10           % Vertical
];

scales_I = [
    0.9, 0.7
];

slopes_I = [
    1.2, 0        % Vertical down
];

current_pos = current_pos + spacing * 0.2;  % I is thinner

% M (4 components)
offsets_M = [
    -20, current_pos;          % Left vertical
    2, current_pos+18 ;      % First diagonal
    2, current_pos+18 ;     % Second diagonal
    -20, current_pos+38      % Right vertical
];

scales_M = [
    0.9, 0.7;
    0.6, 0.7;
    0.6, 0.7;
    0.9, 0.7
];

slopes_M = [
    1.2, 0;       % Left vertical
    1.0, -2;     % First diagonal sloping down right
    1.0, 2;    % Second diagonal sloping down left
    1.2, 0        % Right vertical
];

current_pos = current_pos + spacing * 1.4;  % M is wider

% Z (3 components)
offsets_Z = [
    28, current_pos;          % Top horizontal
    -20, current_pos ;      % Diagonal
    -20, current_pos             % Bottom horizontal
];

scales_Z = [
    1.0, 2.0;
    1.0, 1.0;
    1.0, 2.0
];

slopes_Z = [
    0, 1.2;       % Top horizontal
    1.1, 2.5;    % Diagonal sloping down right
    0, 1.2        % Bottom horizontal
];

current_pos = current_pos + spacing*1.9;

% O (4 components - approximating a circle with 4 arcs)
offsets_O = [
    28, current_pos-15;           % Top arc
    -20, current_pos + 15;      % Right arc
    -20, current_pos-15;             % Bottom arc
    -20, current_pos - 15       % Left arc
];

scales_O = [
    0.5, 2.2;
    1.08, 0.5;
    0.5, 2.2;
    1.08, 0.5
];

slopes_O = [
    0, 1.0;       % Top curve
    1.0, 0;     % Right curve
    0, 1.0;       % Bottom curve
    1.0, 0      % Left curve
];

current_pos = current_pos + spacing;

% D (4 components)
offsets_D = [
    -20, current_pos;           % Vertical
    7, current_pos + 27;       % Top curve
        % Right curve
    -20, current_pos           % Bottom curve
];

scales_D = [
    0.9, 0.7;
    0.5, -2;
    
    0.5, -2
];

slopes_D = [
    1.2, 0;       % Vertical
    1.0, 1.0;       % Top curve
      % Right curve
    1.3, -1        % Bottom curve
];

current_pos = current_pos + spacing*1.2;

% A2 (3 components) - Second A
offsets_A2 = [
    +25, current_pos;          % Left diagonal
    -20, current_pos-15;     % Right diagonal
    0, current_pos-10             % Horizontal bar
];

scales_A2 = [
    1.0, 1;
    1.0, 1;
    0.1, 1.0
];

slopes_A2 = [
    -1, 1.2;    % Left diagonal sloping up and left
    1, 1.2;     % Right diagonal sloping up and right
    0, 1.2        % Horizontal bar
];

current_pos = current_pos + spacing;



% Collect all offsets, scales, and slopes into arrays for each letter group
all_offsets = {offsets_A1, offsets_L, offsets_I, offsets_M, offsets_Z, offsets_O, offsets_D, offsets_A2};
all_scales = {scales_A1, scales_L, scales_I, scales_M, scales_Z, scales_O, scales_D, scales_A2};
all_slopes = {slopes_A1, slopes_L, slopes_I, slopes_M, slopes_Z, slopes_O, slopes_D, slopes_A2};

% --- Plotting ---
figure;
hold on;

% Plot "K"
for i = 1:length(files)
    load(files{i});

    ax = Acceleration.X;
    ay = Acceleration.Y;
    t = seconds(Acceleration.Timestamp - Acceleration.Timestamp(1));
    vx = cumtrapz(t, ax);
    vy = cumtrapz(t, ay);
    x = cumtrapz(t, vx);
    y = cumtrapz(t, vy);

    % Transformations for K
    x = x * scales_K(i, 1) * slopes_K(i, 1);
    y = y * scales_K(i, 2) * slopes_K(i, 2);
    x = x + offsets_K(i, 1);
    y = y + offsets_K(i, 2);

    plot(y, x, 'b', 'LineWidth', 3);
end

% Plot all 3 separate instances of stand.mat for H
for j = 1:3
    x_H = x0_H * scales_H(j, 1) * slopes_H(j, 1);
    y_H = y0_H * scales_H(j, 2) * slopes_H(j, 2);

    x_H = x_H + offsets_H(j, 1);
    y_H = y_H + offsets_H(j, 2);

    plot(y_H, x_H, 'b', 'LineWidth', 3);
end

% Plot all additional letter groups
letter_idx = 1;
component_count = 0;

for g = 1:length(group_sizes)
    letter_size = group_sizes(g);
    letter_offset = all_offsets{g};
    letter_scale = all_scales{g};
    letter_slope = all_slopes{g};
    
    for j = 1:letter_size
        x_letter = x0_std * letter_scale(j, 1) * letter_slope(j, 1);
        y_letter = y0_std * letter_scale(j, 2) * letter_slope(j, 2);

        x_letter = x_letter + letter_offset(j, 1);
        y_letter = y_letter + letter_offset(j, 2);

        plot(y_letter, x_letter, 'b', 'LineWidth', 3);
        component_count = component_count + 1;
    end
    
end

% Add total component count text

xlabel('X Position');
ylabel('Y Position');

grid on;
axis equal;
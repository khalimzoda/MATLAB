load('strokek.mat');  % Your single full-stroke log

ax = Acceleration.X;
ay = Acceleration.Y;
t_full = seconds(Acceleration.Timestamp - Acceleration.Timestamp(1));

% Define motion segments manually
idx1 = 1;
idx2 = 400;     % End of vertical
idx3 = 600;     % End of up-diagonal
idx4 = length(ax);  % End of down-diagonal

segments = {
    idx1, idx2;     % Vertical stroke
    idx2+1, idx3;   % Diagonal up
    idx3+1, idx4    % Diagonal down
};

% Settings per stroke
offsets = [-4, 0;
           0, 0;
           0, 0];

scales = [3.0, 1.0;
          1.2, 1.2;
          1.2, 2];

slopes = [1.0, -0.1;
          1.0, 25.0;
          1.0, 2];

% Plotting
figure;
hold on;

for i = 1:size(segments, 1)
    % Slice for this stroke
    s = segments{i,1};
    e = segments{i,2};

    ax_seg = ax(s:e) - mean(ax(s:e));
    ay_seg = ay(s:e) - mean(ay(s:e));
    t_seg = t_full(s:e);

    vx = cumtrapz(t_seg, ax_seg);
    vy = cumtrapz(t_seg, ay_seg);

    x = cumtrapz(t_seg, vx);
    y = cumtrapz(t_seg, vy);

    % Apply transformation
    x = x * scales(i, 1) * slopes(i, 1);
    y = y * scales(i, 2) * slopes(i, 2);
    x = x + offsets(i, 1);
    y = y + offsets(i, 2);

    % Plot
    plot(-y, x, 'b', 'LineWidth', 6);
end

axis equal;
xlabel('X');
ylabel('Y');
title('Letter K from Single Accelerometer Stroke');
grid on;